const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Data directory (mounted volume for persistence)
const DATA_DIR = path.join(__dirname, 'data');
const CONSENTS_FILE = path.join(DATA_DIR, 'cookie_consents.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Initialize consents file if not exists
if (!fs.existsSync(CONSENTS_FILE)) {
    fs.writeFileSync(CONSENTS_FILE, JSON.stringify([], null, 2));
}

// Helper: Anonymize IP (keep first 3 octets for IPv4)
function anonymizeIP(ip) {
    if (!ip) return 'unknown';
    const parts = ip.split('.');
    if (parts.length === 4) {
        parts[3] = 'XXX';
        return parts.join('.');
    }
    // For IPv6 or other formats, hash it
    return crypto.createHash('sha256').update(ip).digest('hex').substring(0, 16) + '...';
}

// Helper: Generate anonymous user ID
function generateAnonymousID() {
    return 'user_' + crypto.randomBytes(8).toString('hex');
}

// Helper: Get client IP from request
function getClientIP(req) {
    return req.headers['x-forwarded-for']?.split(',')[0]?.trim() || 
           req.headers['x-real-ip'] || 
           req.connection?.remoteAddress || 
           req.socket?.remoteAddress || 
           'unknown';
}

// POST /api/cookie-consent - Log cookie consent
app.post('/api/cookie-consent', (req, res) => {
    try {
        const {
            cookieConsent,      // 'all', 'rejected', 'custom'
            cookieAnalytics,    // true/false
            cookiePreferences,  // true/false
            url                 // Page URL where consent was given
        } = req.body;

        // Validate required fields
        if (!cookieConsent) {
            return res.status(400).json({ error: 'cookieConsent is required' });
        }

        // Get client data
        const clientIP = getClientIP(req);
        const anonymizedIP = anonymizeIP(clientIP);
        const anonymousID = generateAnonymousID();
        const timestamp = new Date().toISOString();

        // Create consent record
        const consentRecord = {
            id: crypto.randomBytes(16).toString('hex'),
            anonymousUserID: anonymousID,
            timestamp: timestamp,
            anonymizedIP: anonymizedIP,
            consentState: cookieConsent,
            cookieAnalytics: cookieAnalytics || false,
            cookiePreferences: cookiePreferences || false,
            url: url || 'unknown',
            userAgent: req.headers['user-agent'] || 'unknown'
        };

        // Read existing consents
        let consents = [];
        try {
            const data = fs.readFileSync(CONSENTS_FILE, 'utf8');
            consents = JSON.parse(data);
        } catch (err) {
            console.error('Error reading consents file:', err);
            consents = [];
        }

        // Add new consent
        consents.push(consentRecord);

        // Save to file
        fs.writeFileSync(CONSENTS_FILE, JSON.stringify(consents, null, 2));

        console.log(`[Cookie Consent] ${consentRecord.anonymousUserID} - ${consentRecord.consentState} - ${consentRecord.url}`);

        res.json({ 
            success: true, 
            message: 'Consent logged successfully',
            recordId: consentRecord.id 
        });

    } catch (error) {
        console.error('Error logging consent:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// GET /api/cookie-consents - Get all consents (for admin)
app.get('/api/cookie-consents', (req, res) => {
    try {
        let consents = [];
        try {
            const data = fs.readFileSync(CONSENTS_FILE, 'utf8');
            consents = JSON.parse(data);
        } catch (err) {
            consents = [];
        }

        // Optional: Filter by date range
        const { from, to } = req.query;
        if (from || to) {
            consents = consents.filter(c => {
                const date = new Date(c.timestamp);
                if (from && date < new Date(from)) return false;
                if (to && date > new Date(to)) return false;
                return true;
            });
        }

        res.json({ 
            success: true, 
            count: consents.length,
            consents 
        });

    } catch (error) {
        console.error('Error reading consents:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// GET /api/cookie-consents/stats - Get consent statistics
app.get('/api/cookie-consents/stats', (req, res) => {
    try {
        let consents = [];
        try {
            const data = fs.readFileSync(CONSENTS_FILE, 'utf8');
            consents = JSON.parse(data);
        } catch (err) {
            consents = [];
        }

        const stats = {
            total: consents.length,
            byConsent: {
                all: consents.filter(c => c.consentState === 'all').length,
                rejected: consents.filter(c => c.consentState === 'rejected').length,
                custom: consents.filter(c => c.consentState === 'custom').length
            },
            analyticsEnabled: consents.filter(c => c.cookieAnalytics === true).length,
            preferencesEnabled: consents.filter(c => c.cookiePreferences === true).length,
            lastUpdated: consents.length > 0 ? consents[consents.length - 1].timestamp : null
        };

        res.json({ success: true, stats });

    } catch (error) {
        console.error('Error getting stats:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.listen(PORT, '0.0.0.0', () => {
    console.log(`Cookie Consent API running on port ${PORT}`);
    console.log(`Data directory: ${DATA_DIR}`);
});
