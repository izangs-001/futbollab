# API de Consentimiento de Cookies

API para registrar el consentimiento de cookies conforme al RGPD.

## 📁 Estructura de Datos Persistente

Los datos se guardan en: `/mnt/WINDOWS/futbol-ranking/cookie-api/data/cookie_consents.json`

Este archivo **persiste fuera del contenedor** y sobrevive a reinicios.

## 🔧 Uso

### Iniciar el servicio
```bash
cd /mnt/WINDOWS/futbol-ranking
docker compose up -d
```

### Ver logs
```bash
docker compose logs -f cookie-api
```

### Acceder a los datos
```bash
cat /mnt/WINDOWS/futbol-ranking/cookie-api/data/cookie_consents.json
```

## 📊 Endpoints

### POST /api/cookie-consent
Registrar nuevo consentimiento.

**Body:**
```json
{
  "cookieConsent": "all",
  "cookieAnalytics": true,
  "cookiePreferences": true,
  "url": "https://estanciasfutbol.com/"
}
```

**Respuesta:**
```json
{
  "success": true,
  "message": "Consent logged successfully",
  "recordId": "abc123..."
}
```

### GET /api/cookie-consents
Obtener todos los consentimientos.

**Query params opcionales:**
- `from`: Fecha inicio (ISO 8601)
- `to`: Fecha fin (ISO 8601)

**Respuesta:**
```json
{
  "success": true,
  "count": 5,
  "consents": [
    {
      "id": "...",
      "anonymousUserID": "user_abc123",
      "timestamp": "2026-03-25T10:00:00.000Z",
      "anonymizedIP": "192.168.1.XXX",
      "consentState": "all",
      "cookieAnalytics": true,
      "cookiePreferences": true,
      "url": "https://estanciasfutbol.com/",
      "userAgent": "Mozilla/5.0..."
    }
  ]
}
```

### GET /api/cookie-consents/stats
Obtener estadísticas de consentimientos.

**Respuesta:**
```json
{
  "success": true,
  "stats": {
    "total": 100,
    "byConsent": {
      "all": 75,
      "rejected": 15,
      "custom": 10
    },
    "analyticsEnabled": 80,
    "preferencesEnabled": 70,
    "lastUpdated": "2026-03-25T10:00:00.000Z"
  }
}
```

### GET /api/health
Health check del servicio.

## 🔒 Datos Registrados

| Campo | Descripción |
|-------|-------------|
| `id` | ID único del registro |
| `anonymousUserID` | ID anónimo del usuario (user_xxx) |
| `timestamp` | Fecha y hora del consentimiento (ISO 8601) |
| `anonymizedIP` | IP anonimizada (último octeto = XXX) |
| `consentState` | Estado: 'all', 'rejected', 'custom' |
| `cookieAnalytics` | Cookies analíticas aceptadas (bool) |
| `cookiePreferences` | Cookies de preferencias aceptadas (bool) |
| `url` | URL donde se dio el consentimiento |
| `userAgent` | User agent del navegador |

## 📁 Backup de Datos

Para hacer backup:
```bash
cp /mnt/WINDOWS/futbol-ranking/cookie-api/data/cookie_consents.json ./backup_cookies_$(date +%Y%m%d).json
```

## 🛡️ Seguridad

- IP anonimizada (último octeto reemplazado por XXX)
- No se almacenan datos personales identificables
- ID de usuario anónimo generado con crypto.randomBytes
- Volumen Docker persistente fuera del contenedor
