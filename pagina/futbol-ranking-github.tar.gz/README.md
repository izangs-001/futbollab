# Estancias Fútbol | Ranking de Estancias de Fútbol en Barcelona

Sitio web profesional para el ranking de estancias de fútbol en Barcelona.

## 🚀 Inicio Rápido

### Iniciar el servidor
```bash
docker compose up -d
```

### Detener el servidor
```bash
docker compose down
```

### Ver logs
```bash
docker compose logs -f
```

## 🔗 Accesos

- **Página Principal:** http://localhost:8443/
- **Página de Ranking:** http://localhost:8443/ranking.html

## 📁 Estructura del Proyecto

```
futbol-ranking/
├── docker-compose.yml    # Configuración Docker Compose
├── Dockerfile            # Instrucciones de construcción
├── nginx.conf            # Configuración de Nginx
├── README.md             # Este archivo
├── IMAGENES_IA.md        # Guía para imágenes IA
└── html/
    ├── index.html        # Página principal (landing page)
    ├── ranking.html      # Página del ranking con formulario
    └── favicon.svg       # Favicon del sitio
```

## 📄 Páginas del Sitio

### 1. Página Principal (index.html)
- **Fondo oscuro** profesional con gradiente verde/dorado
- **Hero section** con introducción sobre Barcelona
- **Secciones informativas:**
  - Nuestra Misión (Análisis, Criterios, Transparencia)
  - Criterios de Análisis (4 tarjetas)
  - Público Objetivo (4 tarjetas)
  - Más Allá del Marketing (problemas del sector)
  - Nuestro Compromiso
- **Botón CTA** que lleva al ranking
- **Footer** con información de contacto

### 2. Página de Ranking (ranking.html)
- **Header verde** con título del ranking
- **Top 5 de academias:**
  1. 🥇 FutbolLab (9.8/10) - MEJOR OPCIÓN
  2. 🥈 MARCET Football (9.2/10)
  3. 🥉 WOSPAC Stages (8.7/10)
  4. Footvia (8.3/10)
  5. Spain Soccer Academy (7.9/10)
- **Formulario de contacto** que envía a n8n
- **Enlace** para volver al inicio

## 🔒 Medidas de Seguridad Implementadas

### Headers de Seguridad
- `X-Frame-Options: SAMEORIGIN` - Previene clickjacking
- `X-Content-Type-Options: nosniff` - Previene MIME sniffing
- `X-XSS-Protection` - Filtro XSS del navegador
- `Permissions-Policy` - Deshabilita geolocalización, mic, cámara
- `Referrer-Policy` - Controla información de referer

### Nginx
- Versión oculta (`server_tokens off`)
- Métodos HTTP permitidos: GET, HEAD, POST, OPTIONS
- Límite de tamaño de body (2MB)
- Timeouts reducidos para prevenir ataques
- Bloqueo de archivos sensibles (.git, .env, backups)

### Docker
- Usuario sin privilegios (no root)
- Límite de CPU (0.5 cores)
- Límite de memoria (256MB)
- `no-new-privileges` activado
- Volúmenes de solo lectura

### Formulario de Contacto
- Validación del lado del cliente
- Sanitización básica de inputs
- CORS configurado correctamente

## 📧 Formulario de Contacto - n8n Webhook

### Configuración del Webhook en n8n

**URL del Webhook:**
```
https://izangs1.app.n8n.cloud/webhook-test/estancias.futbol-webhook
```

### Método: POST

### Datos que recibe el webhook (JSON):

```json
{
  "parentName": "Nombre del padre/tutor",
  "email": "email@ejemplo.com",
  "phone": "+34 600 000 000",
  "playerName": "Nombre del jugador",
  "playerAge": 15,
  "playerPosition": "Delantero",
  "preferredProgram": "FutbolLab",
  "travelDate": "2026-06-15",
  "message": "Mensaje adicional del usuario",
  "timestamp": "2026-03-25T10:30:00.000Z",
  "userAgent": "Mozilla/5.0...",
  "source": "http://localhost:8443/ranking.html"
}
```

### Configuración recomendada en n8n:

1. **Webhook Node:**
   - HTTP Method: `POST`
   - Path: `estancias.futbol-webhook`
   - Response Mode: `Last Node`

2. **Para guardar en base de datos:**
   - Conecta el Webhook a un nodo de base de datos (MySQL, PostgreSQL, MongoDB, etc.)
   - O usa Google Sheets / Airtable para empezar

3. **Respuesta esperada:**
   - El webhook debe responder con status 200 OK

## 🎨 Diseño y Estilo

### Paleta de Colores
| Color | Valor | Uso |
|-------|-------|-----|
| Fondo Oscuro | `#0a1f1a` | Fondo principal |
| Fondo Card | `#132f27` | Tarjetas y secciones |
| Primary | `#10b981` | Elementos destacados |
| Primary Light | `#34d399` | Hover y acentos |
| Accent | `#fbbf24` | Dorado, CTA, mejor opción |
| Texto Primary | `#f9fafb` | Texto principal |
| Texto Secondary | `#9ca3af` | Texto secundario |

### Tipografía
- **Títulos:** Montserrat (700, 800)
- **Cuerpo:** Open Sans (400, 500, 600)

## 📦 Crear Imagen Docker

```bash
docker build -t estancias-futbol:latest .
```

## 🌐 Subir a Docker Hub

```bash
# Login
docker login

# Tag
docker tag estancias-futbol:latest tu-usuario/estancias-futbol:latest

# Push
docker push tu-usuario/estancias-futbol:latest
```

## 🛠️ Producción

### Para producción:

1. **Cambiar URL del webhook:**
   - Reemplaza `webhook-test` por `webhook` en ranking.html
   - URL producción: `https://izangs1.app.n8n.cloud/webhook/estancias.futbol-webhook`

2. **Configurar dominio y SSL:**
   - Usa un reverse proxy (nginx, Traefik, Caddy)
   - Configura SSL con Let's Encrypt

3. **Optimizar nginx:**
   - Habilitar gzip
   - Configurar cacheo apropiado
   - Ajustar worker processes

## 📊 Ranking Actual

| Posición | Programa | Puntuación |
|----------|----------|------------|
| 🥇 1 | **FutbolLab** | 9.8/10 ⭐ MEJOR OPCIÓN |
| 🥈 2 | MARCET Football | 9.2/10 |
| 🥉 3 | WOSPAC Stages | 8.7/10 |
| 4 | Footvia | 8.3/10 |
| 5 | Spain Soccer Academy | 7.9/10 |

---

© 2026 Estancias Fútbol. Todos los derechos reservados.
