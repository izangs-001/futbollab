(function() {
    'use strict';

    // Cookie helper functions
    function setCookie(name, value, days) {
        var expires = '';
        if (days) {
            var date = new Date();
            date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
            expires = '; expires=' + date.toUTCString();
        }
        document.cookie = name + '=' + (value || '') + expires + '; path=/; SameSite=Lax';
    }

    function getCookie(name) {
        var nameEQ = name + '=';
        var ca = document.cookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) === ' ') c = c.substring(1, c.length);
            if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
        }
        return null;
    }

    // Log consent to API
    function logConsentToAPI(consentData) {
        fetch('/api/cookie-consent', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(consentData)
        })
        .then(function(response) {
            if (response.ok) {
                console.log('Consent logged successfully');
            } else {
                console.error('Failed to log consent');
            }
        })
        .catch(function(error) {
            console.error('Error logging consent:', error);
        });
    }

    // Check if consent already given
    var cookieConsent = getCookie('cookie_consent');
    
    if (!cookieConsent) {
        // Show banner after 2 seconds
        setTimeout(function() {
            showBanner();
        }, 2000);
    }

    function showBanner() {
        var banner = document.getElementById('cookieBanner');
        if (banner) {
            banner.classList.add('show');
        }
    }

    function hideBanner() {
        var banner = document.getElementById('cookieBanner');
        if (banner) {
            banner.classList.remove('show');
        }
    }

    // Accept all cookies
    window.acceptAllCookies = function() {
        setCookie('cookie_consent', 'all', 365);
        setCookie('cookie_analytics', 'true', 365);
        setCookie('cookie_preferences', 'true', 365);
        
        // Log consent
        logConsentToAPI({
            cookieConsent: 'all',
            cookieAnalytics: true,
            cookiePreferences: true,
            url: window.location.href
        });
        
        hideBanner();
        hideModal();
        console.log('Cookies aceptadas: todas');
    };

    // Reject all cookies
    window.rejectAllCookies = function() {
        setCookie('cookie_consent', 'rejected', 365);
        setCookie('cookie_analytics', 'false', 365);
        setCookie('cookie_preferences', 'false', 365);
        
        // Log consent
        logConsentToAPI({
            cookieConsent: 'rejected',
            cookieAnalytics: false,
            cookiePreferences: false,
            url: window.location.href
        });
        
        hideBanner();
        hideModal();
        console.log('Cookies rechazadas: todas');
    };

    // Save custom configuration
    window.saveCookieConfig = function() {
        var analytics = document.getElementById('cookieAnalytics') ? document.getElementById('cookieAnalytics').checked : false;
        var preferences = document.getElementById('cookiePreferences') ? document.getElementById('cookiePreferences').checked : false;
        
        setCookie('cookie_consent', 'custom', 365);
        setCookie('cookie_analytics', analytics.toString(), 365);
        setCookie('cookie_preferences', preferences.toString(), 365);
        
        // Log consent
        logConsentToAPI({
            cookieConsent: 'custom',
            cookieAnalytics: analytics,
            cookiePreferences: preferences,
            url: window.location.href
        });
        
        hideBanner();
        hideModal();
        console.log('Configuración guardada: analytics=' + analytics + ', preferences=' + preferences);
    };

    // Modal functions
    window.openCookieConfig = function() {
        var modal = document.getElementById('cookieModal');
        if (modal) {
            modal.classList.add('show');
        }
    };

    function hideModal() {
        var modal = document.getElementById('cookieModal');
        if (modal) {
            modal.classList.remove('show');
        }
    }

    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
        var modal = document.getElementById('cookieModal');
        if (event.target === modal) {
            hideModal();
        }
    });

    // Initialize necessary cookies (strictly necessary - always active)
    setCookie('cookie_necessary', 'true', 365);

})();
